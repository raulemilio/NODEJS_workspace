# Proyecto integrador DAIoT- Frontend

## Presentación del proyecto e información del front-back

Descripción sobre el Backend y el Frontend:

- [Descripción del backend-Frontend](https://raw.githubusercontent.com/raulemilio/romero_TI_frontend/main/documentos/Trabajo_Practico_Back-end_front-end.pdf)

Presentación del proyecto

- [Presentación](https://github.com/raulemilio/romero_TI_frontend/blob/main/documentos/presentaci%C3%B3n_proyecto.pdf) 

NOTA: Se deben descargar los archivos para poder visualizarlos.
