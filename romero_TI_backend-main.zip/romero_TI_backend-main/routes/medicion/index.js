var express = require('express');
var routerMedicion = express.Router();
var pool = require('../../mysql');

//Espera recibir por parámetro un id de dispositivo y devuelve su última medición
routerMedicion.get('/:idDispositivo', function(req, res) {
    pool.query('Select * from Mediciones where dispositivoId=? order by fecha desc', [req.params.idDispositivo], function(err, result, fields) {
        if (err) {
            res.send(err).status(400);
            console.log("Error: no se pudo enviar la última mediciones del dispositivo "+req.params.idDispositivo);
            return;
        }
        console.log("Se envió al cliente la última medición para el dispositivo "+req.params.idDispositivo);
        res.send(result[0]);
        console.log("Se envió al cliente la última medición para el dispositivo "+ result[0]);
    });
});

//Espera recibir por parámetro un id de dispositivo y devuelve todas sus mediciones
routerMedicion.get('/:idDispositivo/todas', function(req, res) {
    pool.query('Select * from Mediciones where dispositivoId=? order by fecha desc', [req.params.idDispositivo], function(err, result, fields) {
        if (err) {
            res.send(err).status(400);
            console.log("Error: no se pudo enviar el listado de mediciones del dispositivo "+req.params.idDispositivo);
            return;
        }
        console.log("Se envió al cliente el listado de mediciones para el dispositivo "+req.params.idDispositivo);
        res.send(result);
    });
});

//Espera recibir por parámetro un id de dispositivo y un valor de medición y lo inserta en base de datos.
routerMedicion.post('/agregar', function(req, res) {
    /*
    pool.query('Insert into Mediciones (fecha,valor,dispositivoId) values (?,?,?)', [req.body.fecha, req.body.valor, req.body.dispositivoId], function(err, result, fields) {
        if (err) {
            res.send(err).status(400);
            console.log("Error: no se pudo registrar la última medición del dispositivo "+req.body.dispositivoId);
            return;
        }
        console.log("Se registró  medición en el dispositivo "+req.body.dispositivoId);
        res.send(result);
    });
*/
});

module.exports = routerMedicion;